import React from 'react';
import { ArrowRight, Download, Users, BarChart3, Clock, CheckCircle } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          <div className="flex flex-col items-center mx-auto">
            <h1 className="text-2xl font-bold tracking-wider text-slate-900">DHARMA TRADE</h1>
            <span className="text-sm tracking-widest text-slate-600">ACADEMY</span>
          </div>
        </nav>
      </header>

      {/* Hero Section */}
      <section className="relative">
        <div className="absolute inset-0">
          <img
            className="w-full h-full object-cover"
            src="https://images.unsplash.com/photo-1642790106117-e829e14a795f?auto=format&fit=crop&q=80"
            alt="Trading background"
          />
          <div className="absolute inset-0 bg-slate-900/70 mix-blend-multiply" />
        </div>
        <div className="relative max-w-7xl mx-auto py-24 px-4 sm:py-32 sm:px-6 lg:px-8">
          <h2 className="text-4xl font-extrabold tracking-tight text-white sm:text-5xl lg:text-6xl text-center">
            Be part of the change
          </h2>
          <p className="mt-6 max-w-3xl mx-auto text-xl text-slate-200 text-center">
            Transform your trading journey with expert tools and knowledge
          </p>
          <div className="mt-10 flex justify-center gap-4">
            <button className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700">
              Explore Products
              <ArrowRight className="ml-2 -mr-1 h-5 w-5" />
            </button>
            <button className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-blue-600 bg-white hover:bg-slate-50">
              Join Academy
            </button>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-extrabold text-slate-900">Why Choose Dharma Trade Academy</h2>
            <p className="mt-4 text-lg text-slate-600">
              Experience the difference with our comprehensive trading solutions
            </p>
          </div>

          <div className="mt-12 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
            {[
              {
                icon: <BarChart3 className="h-8 w-8 text-blue-600" />,
                title: 'Advanced Software',
                description: 'State-of-the-art trading tools designed for success'
              },
              {
                icon: <Download className="h-8 w-8 text-blue-600" />,
                title: 'Instant Downloads',
                description: 'Get immediate access to all your purchased resources'
              },
              {
                icon: <Users className="h-8 w-8 text-blue-600" />,
                title: 'Expert Support',
                description: '24/7 assistance from our professional team'
              },
              {
                icon: <Clock className="h-8 w-8 text-blue-600" />,
                title: 'Real-time Updates',
                description: 'Stay ahead with live market insights'
              },
              {
                icon: <CheckCircle className="h-8 w-8 text-blue-600" />,
                title: 'Verified Strategies',
                description: 'Proven methods tested by industry experts'
              }
            ].map((benefit, index) => (
              <div
                key={index}
                className="relative p-6 bg-slate-50 rounded-lg hover:shadow-md transition-shadow"
              >
                <div className="flex items-center justify-center w-16 h-16 bg-blue-100 rounded-full mx-auto">
                  {benefit.icon}
                </div>
                <h3 className="mt-4 text-lg font-medium text-slate-900 text-center">
                  {benefit.title}
                </h3>
                <p className="mt-2 text-base text-slate-600 text-center">
                  {benefit.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-16 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-extrabold text-slate-900 text-center">
            What Our Students Say
          </h2>
          <div className="mt-12 grid gap-8 lg:grid-cols-3">
            {[
              {
                quote: "The tools and knowledge provided by Dharma Trade Academy transformed my approach to trading.",
                author: "Sarah Chen",
                role: "Professional Trader"
              },
              {
                quote: "Best investment I've made in my trading career. The support team is incredibly helpful.",
                author: "Michael Rodriguez",
                role: "Day Trader"
              },
              {
                quote: "Their software solutions gave me the edge I needed in the market. Highly recommended!",
                author: "David Kim",
                role: "Forex Trader"
              }
            ].map((testimonial, index) => (
              <div
                key={index}
                className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow"
              >
                <p className="text-slate-600 italic">"{testimonial.quote}"</p>
                <div className="mt-4">
                  <p className="font-medium text-slate-900">{testimonial.author}</p>
                  <p className="text-slate-600 text-sm">{testimonial.role}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-2xl font-bold tracking-wider">DHARMA TRADE</h2>
            <p className="text-sm tracking-widest">ACADEMY</p>
            <p className="mt-4 text-slate-400">Be part of the change</p>
          </div>
          <div className="mt-8 text-center text-slate-400 text-sm">
            © {new Date().getFullYear()} Dharma Trade Academy. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;